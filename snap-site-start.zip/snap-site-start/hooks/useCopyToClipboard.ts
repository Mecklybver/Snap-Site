export default function useCopyToClipboard() {}
