export default function GenerateButton() {
  return "generate button";
}
